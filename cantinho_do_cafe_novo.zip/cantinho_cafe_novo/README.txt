CANTINHO DO CAFÉ - NOVA VERSÃO

Arquivos:
- index.html
- manifest.json
- logo.png

Publique os três arquivos na raiz do GitHub Pages, substituindo os antigos.
Depois, no celular, abra o site novamente e remova/adicione o atalho à tela inicial para atualizar o ícone.
